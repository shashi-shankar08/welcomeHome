package raj;

public class WelcomeHome {
	public static void main(String[] args) {
	System.out.println("Hey raj, welcome to Home");

}
}
